/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1;

/**
 *
 * @author ADMIN
 */
public class Book extends Document{
    private int page;
    private String status;

    public Book(int page, String status, String ID, String name) {
        super(ID, name);
        this.page = page;
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }
    @Override
    public String entryDoc(){
        return String.format("Add book: %s - %s - %d pages - %s", getID(), getName(), page, status);
    }
    
    @Override
    public String printBook(){
        return String.format("%s - %s - %d pages - %s", getID(), getName(), page, status);
    }
    
    public void borrowBook(){
 
    }
    
    public void returnBook(){
        
    }
}
